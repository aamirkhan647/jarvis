"""Error Handler Module"""

def main():
    pass
