"""Decorators Module"""

def main():
    pass
