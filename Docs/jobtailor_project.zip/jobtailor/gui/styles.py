"""Styles Module"""

def main():
    pass
