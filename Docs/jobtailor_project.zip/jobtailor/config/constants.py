"""Constants Module"""

def main():
    pass
