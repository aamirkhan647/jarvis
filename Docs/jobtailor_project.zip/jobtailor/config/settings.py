"""Settings Module"""

def main():
    pass
