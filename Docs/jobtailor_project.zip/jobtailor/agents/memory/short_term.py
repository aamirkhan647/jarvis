"""Short Term Module"""

def main():
    pass
