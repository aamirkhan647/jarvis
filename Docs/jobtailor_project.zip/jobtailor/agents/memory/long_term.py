"""Long Term Module"""

def main():
    pass
