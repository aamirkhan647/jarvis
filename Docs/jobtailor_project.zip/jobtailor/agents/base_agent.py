"""Base Agent Module"""

def main():
    pass
