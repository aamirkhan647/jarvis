"""Rules Module"""

def main():
    pass
