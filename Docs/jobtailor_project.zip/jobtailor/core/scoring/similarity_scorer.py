"""Similarity Scorer Module"""

def main():
    pass
