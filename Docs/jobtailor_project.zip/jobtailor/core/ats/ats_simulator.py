"""Ats Simulator Module"""

def main():
    pass
