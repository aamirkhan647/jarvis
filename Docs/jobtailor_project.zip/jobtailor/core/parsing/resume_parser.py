"""Resume Parser Module"""

def main():
    pass
